import { useState, useEffect } from 'react';
import { Heart, MessageCircle, Send, Shield } from 'lucide-react';

interface Post {
  id: number;
  username: string;
  avatar: string;
  caption: string;
  likes: number;
  comments: number;
  image: string;
}

function App() {
  const [appState, setAppState] = useState<'login' | 'feed'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [posts, setPosts] = useState<Post[]>([]);
  const [newComment, setNewComment] = useState('');
  const [showToxicWarning, setShowToxicWarning] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [isTyping, setIsTyping] = useState(false);

  const toxicWords = ['stupid', 'idiot', 'hate', 'dumb', 'loser'];

  const checkToxicity = (text: string): boolean => {
    const lowerText = text.toLowerCase();
    return toxicWords.some(word => lowerText.includes(word));
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username && password) {
      setTimeout(() => {
        setAppState('feed');
        setPosts([
          {
            id: 1,
            username: 'sarah_adventures',
            avatar: 'SA',
            caption: 'Beautiful sunset at the beach today! 🌅',
            likes: 234,
            comments: 12,
            image: 'gradient-1'
          },
          {
            id: 2,
            username: 'food_explorer',
            avatar: 'FE',
            caption: 'Tried this amazing new restaurant downtown',
            likes: 189,
            comments: 8,
            image: 'gradient-2'
          },
          {
            id: 3,
            username: 'fitness_daily',
            avatar: 'FD',
            caption: 'Morning workout complete! Feeling energized 💪',
            likes: 312,
            comments: 15,
            image: 'gradient-3'
          }
        ]);
      }, 300);
    }
  };

  const handleCommentChange = (text: string) => {
    setNewComment(text);
    setIsTyping(text.length > 0);

    if (checkToxicity(text)) {
      setShowToxicWarning(true);
      setShowSuccess(false);
    } else {
      setShowToxicWarning(false);
    }
  };

  const handlePostComment = () => {
    if (newComment && !checkToxicity(newComment)) {
      setShowSuccess(true);
      setShowToxicWarning(false);
      setTimeout(() => {
        setNewComment('');
        setShowSuccess(false);
        setIsTyping(false);
      }, 2000);
    }
  };

  if (appState === 'login') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <div className="w-full max-w-md animate-fade-in">
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-500 rounded-full mb-4 animate-scale-in">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-slate-800 mb-2">SafeGram</h1>
              <p className="text-slate-500 text-sm">A safer social experience</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-700">Username</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
                  placeholder="Enter your username"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-700">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition-all"
                  placeholder="Enter your password"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 rounded-lg transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-blue-500/30"
              >
                Login
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-slate-800">SafeGram</h1>
          </div>
          <div className="text-sm text-slate-600">Welcome, {username}</div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {posts.map((post, index) => (
          <div
            key={post.id}
            className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden animate-slide-in"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <div className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                {post.avatar}
              </div>
              <div>
                <h3 className="font-semibold text-slate-800">{post.username}</h3>
                <p className="text-xs text-slate-500">2 hours ago</p>
              </div>
            </div>

            <div className={`w-full h-64 bg-gradient-to-br ${
              post.image === 'gradient-1' ? 'from-orange-400 to-pink-500' :
              post.image === 'gradient-2' ? 'from-emerald-400 to-cyan-500' :
              'from-violet-400 to-fuchsia-500'
            }`} />

            <div className="p-4 space-y-3">
              <div className="flex items-center gap-4">
                <button className="flex items-center gap-2 text-slate-700 hover:text-red-500 transition-colors">
                  <Heart className="w-6 h-6" />
                </button>
                <button className="flex items-center gap-2 text-slate-700 hover:text-blue-500 transition-colors">
                  <MessageCircle className="w-6 h-6" />
                </button>
              </div>

              <div>
                <p className="font-semibold text-slate-800 text-sm">{post.likes.toLocaleString()} likes</p>
                <p className="text-slate-800 text-sm mt-1">
                  <span className="font-semibold">{post.username}</span> {post.caption}
                </p>
                <p className="text-slate-500 text-sm mt-1">View all {post.comments} comments</p>
              </div>

              {post.id === 1 && (
                <div className="pt-3 border-t border-slate-200">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newComment}
                      onChange={(e) => handleCommentChange(e.target.value)}
                      placeholder="Add a comment..."
                      className="flex-1 px-3 py-2 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none text-sm transition-all"
                    />
                    <button
                      onClick={handlePostComment}
                      disabled={!newComment || showToxicWarning}
                      className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all disabled:bg-slate-300 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>

                  {showToxicWarning && (
                    <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg animate-blink">
                      <p className="text-red-700 text-sm font-medium flex items-center gap-2">
                        <span className="text-lg">⚠️</span>
                        Toxic content detected — please revise your comment
                      </p>
                    </div>
                  )}

                  {showSuccess && (
                    <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 rounded-lg animate-fade-in">
                      <p className="text-emerald-700 text-sm font-medium flex items-center gap-2">
                        <span className="text-lg">✅</span>
                        Posted Successfully
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </main>
    </div>
  );
}

export default App;
